/*
 HTTP Cloud Function.

 @param {Object} req Cloud Function request context.
 @param {Object} res Cloud Function response context.
*/

const mysql = require('mysql');

var sql = '';

var params = '';
var conn = mysql.createConnection({
   host : 'sqldb.cmsrxuizyrwq.ap-northeast-2.rds.amazonaws.com',
   user : 'mysql_db',
   password : 'syteam1111',
   database : 'syteam',
   port : 3306
 });

var query = '';

conn.connect();

exports.helloHttp = function helloHttp (req, res) {
  var action = req.body.result['action'];
  var nickname = req.body.result.parameters['nickname'];
  var user_id = req.body.result.parameters['user_id'];
  var resolvedQuery = req.body.result['resolvedQuery'];



  function todoFunction(callback){

      conn.query(sql, params, function(err, rows, fields){
           if(err){
             console.log(err);
             response = 'DB연결 실패ㅠㅠ' + err;
            //  app.tell('쿼리실패' + query);
             callback();
           } else{
                query = '';
                for(var i=0; i<rows.length;i++){
             				    console.log('로우즈 ' + rows[i].TODO_LIST);
               				  if(i == rows.length - 1){
               					      query += rows[i].TODO_LIST;
               				  }
               				  else{
               					      query += rows[i].TODO_LIST +', ';
               				  }
             		}
              if(query != ''){
                response = params + '의 할일은 "'+ query + '"입니다.';
              }else {
                response = params + '의 할일은 없습니다.';
              }
              callback();
           }
           response = 'test';
     });

   }

   function projectmemberListFunction(callback){
      conn.query(sql, params, function(err, rows, fields){
          if(err){
            console.log(err);
            response = 'DB연결 실패ㅠㅠ' + err;
            callback();
          } else{
            query = '';
            for(var i=0; i<rows.length;i++){
                if(i == rows.length - 1){
                    query += rows[i].MEMBER_NICKNAME;
                } else{
                    query += rows[i].MEMBER_NICKNAME + ', ';
                }
            }
            if(query != ''){
               response = params + ' 프로젝트의 멤버는 "' + query + '"입니다. 멤버를 추가하시겠습니까?';
            }else{
              response = params + ' 프로젝트의 멤버는 없습니다. 멤버를 추가하시겠습니까?'
            }
            callback();
          }
      });

   }

   function serchNicknameFuction(){
      var serchSQL = 'SELECT USER_NAME FROM USER_TABLE WHERE USER_ID = ?';
      params = user_id;
      conn.query(serchSQL, params, function(err, rows, fields){
          if(err){
            console.log(err);
            response = 'DB연결 실패ㅠㅠ' + err;
          } else{
            return rows[0].USER_NAME;

          }

      });

   }


    if(action == 'todo.nickname'){
          sql = 'SELECT T.TODO_LIST FROM TODO_LIST_TABLE T, TODO_MEMBER_TABLE M WHERE T.TODO_NO = M.TODO_NO AND M.MEMBER_NICKNAME = ?'
          params = nickname;
          todoFunction(function(){
              res.setHeader('Content-Type', 'application/json'); //Requires application/json MIME type
              res.send(JSON.stringify({ "speech": response, "displayText": response  }));
            });
    }else if (action == 'project.memberlist') {
          sql = 'SELECT M.MEMBER_NICKNAME FROM PROJECT_TABLE P, MEMBER_TABLE M WHERE P.PROJECT_ID = M.PROJECT_ID AND PROJECT_NAME = ?'
          params = '한청화';
          projectmemberListFunction(function(){
            res.setHeader('Content-Type', 'application/json'); //Requires application/json MIME type
            res.send(JSON.stringify({ "speech": response, "displayText": response  }));
          });
    }else if(action == 'project.inputMember'){
          // sql = 'INSERT INTO MEMBER_TABLE VALUES(?, ?, ?, ?)'
          response = 'db타기전';
          var serchedNickname = serchNicknameFuction(); //
          response = serchedNickname;
          // params = [1004, nickname, 'n', user_id];
          // projectinputMemberFunction(function(){
            res.setHeader('Content-Type', 'application/json'); //Requires application/json MIME type
            res.send(JSON.stringify({ "speech": response, "displayText": response  }));
          // });
    }
};
